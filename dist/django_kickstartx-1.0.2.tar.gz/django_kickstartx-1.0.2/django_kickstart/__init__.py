"""Django Kickstart — Scaffold production-ready Django projects in seconds."""

__version__ = "1.0.2"
